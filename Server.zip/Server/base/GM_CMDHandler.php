<?php
//执行函数
class GM_CMDHandler
{
	/**
	 * 
	 * @return 成功返回data object对象或者true
	 * 失败返回空值
	 * @param $gmData
	 * @param $gm_Mgr
	 */
	public static function handle_server_changeGameServerState($gmData,GM_Mgr $gm_Mgr){
		return $gm_Mgr->serverData->changeServerState($gmData->{'gameServerCode'},
		$gmData->{'gameServerState'});
	}

	public static function handle_server_getGameServerList($gmData,GM_Mgr $gm_Mgr){
		

		$anonObj = Util::anon_class();
		$anonObj->{'gameServerList'} = $gm_Mgr->serverData->getGMServerList();
		return $anonObj;
	}
}