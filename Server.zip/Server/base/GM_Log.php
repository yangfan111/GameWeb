<?php
class GM_Log{


	


}