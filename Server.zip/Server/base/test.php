<?php 

	phpinfo();
?>