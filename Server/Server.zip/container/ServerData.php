<?php

class ServerData{


	private $channel_DEV = array("1","2","3","4","5","6","7");
	private $channel_CJ=array("1");
	private $channel_QA =array("1","2");


	// const QA = 2;
	// const CJ = 3;

	public  $serverList =  array();
	//当前服务器列表

	public  function getGMServerList($channel = 'channel_DEV')
	{
		
		$gmSrvArr = array();
		$tarServerList= null;
		switch ($channel) {
			case 'channel_DEV':
				$tarServerList=$this->channel_DEV;
				break;
			case 'channel_CJ':
				$tarServerList=$this->channel_CJ;

				break;
			case 'channel_QA':
				$tarServerList=$this->channel_QA;

				break;
			
		}
		foreach ($tarServerList as $key) {
			# code...
			array_push($gmSrvArr,$this->serverList[$key]->getGMObject());
		}
		// foreach ($this->serverList as $key =>$value) {

		// 	array_push($gmSrvArr, $value->getGMObject());
		// }
		return $gmSrvArr;
	}
	public function changeServerState($serverCode,$tarServerState)
	{
		if(!isset($this->serverList[$serverCode]))
		{
			return;
		}
		$this->serverList[$serverCode]->gameSerpverState =$tarServerState;
		return true;
	}
	function __construct($serverDataArr){
		// $this->channel_DEV = array(
		// 	'name'=>'channel_DEV',
		// 	'serverList'=>array("1","2","3","4","5","6","7")
		// );
		// $this->channel_CJ = array(
		// 	'name'=>'channel_CJ',
		// 	'serverList'=>array("1")
		// );
		// $this->channel_QA = array(
		// 	'name'=>'channel_QA',
		// 	'serverList'=>array(1,2)
		// );

		if(count($this->serverList)>0)
		{
			unset($this->serverList);
		}
		
		foreach ($serverDataArr->ServerList as $serverData)
		{
		//	print_r($serverData);

			$this->serverList[$serverData->{'gameServerCode'}] = new ServerInfo($serverData);

		}
		//	print(count($this->serverList));
	}

}




