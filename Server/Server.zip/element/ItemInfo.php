<?php
class ItemInfo extends GMEntry
{
	public $itemCode;
	public $itemNum;
}